import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/feature_card.dart';
import 'modules/rx_assistant.dart';
import 'modules/visit_planner.dart';
import 'modules/kpi_dashboard.dart';
import 'modules/drug_cards.dart';
import 'modules/surprise_module.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hızır', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        centerTitle: true,
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        children: const [
          FeatureCard(title: 'Rx Asistan', subtitle: 'Doz/yan etki rehberi', icon: Icons.medication, screen: RxAssistantScreen()),
          FeatureCard(title: 'Ziyaret Planlayıcı', subtitle: 'Hedef hekim/gün', icon: Icons.route, screen: VisitPlannerScreen()),
          FeatureCard(title: 'KPI Paneli', subtitle: 'Aylık hedef/gerçekleşen', icon: Icons.bar_chart, screen: KpiDashboardScreen()),
          FeatureCard(title: 'İlaç Kartları', subtitle: 'Sunitinib/Pazopanib vb.', icon: Icons.library_books, screen: DrugCardsScreen()),
          FeatureCard(title: 'Sürpriz Modül', subtitle: 'Akıllı İçgörü', icon: Icons.auto_awesome, screen: SurpriseModuleScreen()),
          FeatureCard(title: 'Ayarlar', subtitle: 'Karanlık tema vb.', icon: Icons.settings, screen: PlaceholderScreen()),
        ],
      ),
    );
  }
}

class PlaceholderScreen extends StatelessWidget {
  const PlaceholderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: const Center(child: Text('Yakında...')),
    );
  }
}
