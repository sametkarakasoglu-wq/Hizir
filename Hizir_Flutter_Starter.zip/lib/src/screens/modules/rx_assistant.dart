import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RxAssistantScreen extends StatefulWidget {
  const RxAssistantScreen({super.key});

  @override
  State<RxAssistantScreen> createState() => _RxAssistantScreenState();
}

class _RxAssistantScreenState extends State<RxAssistantScreen> {
  String drug = 'Sunitinib';
  double weight = 70;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rx Asistan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Doz Önerisi (örnek/temsili)', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: drug,
            items: const [
              DropdownMenuItem(value: 'Sunitinib', child: Text('Sunitinib (SUTESGO)')),
              DropdownMenuItem(value: 'Pazopanib', child: Text('Pazopanib (Vopazzi)')),
            ],
            onChanged: (v) => setState(() => drug = v ?? 'Sunitinib'),
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'İlaç'),
          ),
          const SizedBox(height: 12),
          Slider(
            value: weight,
            min: 40,
            max: 120,
            divisions: 80,
            label: f'{weight:.0f} kg',
            onChanged: (v) => setState(() => weight = v),
          ),
          Text('Ağırlık: ${weight.round()} kg'),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(_doseSuggestion(), style: GoogleFonts.poppins(fontSize: 14)),
            ),
          ),
          const SizedBox(height: 16),
          Text('Yan Etki Yönetimi (özet)', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('• El-ayak sendromu: dereceye göre doz arası/azaltma\n• Hipertansiyon: düzenli ölçüm + antihipertansif\n• Hepatotoksisite: LFT izlemi, gerekirse kesinti'),
        ],
      ),
    );
  }

  String _doseSuggestion() {
    if (drug == 'Sunitinib') {
      return 'Başlangıç 50 mg (4/2 şeması). Tolerans sorununda 37.5 mg tek form (SUTESGO) pratik olabilir.';
    }
    return 'Pazopanib 800 mg/gün aç karnına. Karaciğer enzimlerine göre izlem ve gerektiğinde kesinti.';
  }
}
