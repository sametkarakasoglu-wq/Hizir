import 'package:flutter/material.dart';

class DrugCardsScreen extends StatelessWidget {
  const DrugCardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('İlaç Kartları')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Card(child: ListTile(title: Text('Sunitinib (SUTESGO)'), subtitle: Text('MOA: Multikinaz inhibitörü. Not: 37.5 mg tek form opsiyonu.'))),
          Card(child: ListTile(title: Text('Pazopanib (Vopazzi)'), subtitle: Text('MOA: TKİ. Not: Karaciğer fonksiyon izlemi önemli.'))),
          Card(child: ListTile(title: Text('Abirateron'), subtitle: Text('MOA: CYP17 inhibitörü. Not: Prednizolon eşlik eder.'))),
        ],
      ),
    );
  }
}
