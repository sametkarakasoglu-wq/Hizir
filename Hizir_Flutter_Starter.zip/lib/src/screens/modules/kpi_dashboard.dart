import 'package:flutter/material.dart';

class KpiDashboardScreen extends StatelessWidget {
  const KpiDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('KPI Paneli')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          ListTile(title: Text('Aylık hedef: 12 yeni hasta'), subtitle: Text('Gerçekleşen: 9')),
          ListTile(title: Text('SUNITINIB – 37.5 mg tercih oranı'), subtitle: Text('%48 (Ümraniye EAH eğilimi)')),
          ListTile(title: Text('Ziyaret sayısı'), subtitle: Text('Bu ay: 22 / Hedef: 24')),
        ],
      ),
    );
  }
}
