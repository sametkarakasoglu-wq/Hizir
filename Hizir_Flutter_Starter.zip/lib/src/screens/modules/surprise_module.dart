import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class SurpriseModuleScreen extends StatefulWidget {
  const SurpriseModuleScreen({super.key});

  @override
  State<SurpriseModuleScreen> createState() => _SurpriseModuleScreenState();
}

class _SurpriseModuleScreenState extends State<SurpriseModuleScreen> {
  final items = <InsightItem>[
    InsightItem(center: 'Ümraniye EAH', owner: 'Prof. Dr. Melike Özçelik', keyPoint: 'RCC’da sunitinib eğilimi yüksek; 37.5 mg tek form farkını vurgula.'),
    InsightItem(center: 'Göztepe Şehir Hast.', owner: 'Doç. Dr. Sinan Koca', keyPoint: 'Sunumda yan etki yönetim akış şeması hazır bulunsun.'),
    InsightItem(center: 'Kocaeli Üniversitesi', owner: 'Prof. Dr. Umut Kefeli', keyPoint: 'Pazopanib karaciğer izlemi vurgusu + vaka kartı.'),
    InsightItem(center: 'Haydarpaşa Numune EAH', owner: 'Dr. Hatice Güngör', keyPoint: 'Yeni hasta deneyimi talebi – vaka payı artırma.'),
  ];

  DateTime? reminder;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Akıllı Klinik İçgörü')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final i in items)
            Card(
              child: ListTile(
                title: Text('${i.center} – ${i.owner}'),
                subtitle: Text(i.keyPoint),
                trailing: IconButton(
                  icon: const Icon(Icons.note_add),
                  onPressed: () => _openTemplate(context, i),
                ),
              ),
            ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: Text(reminder == null ? 'Hatırlatma: seçilmedi' : 'Hatırlatma: ${DateFormat('dd.MM.yyyy HH:mm').format(reminder!)}')),
              ElevatedButton(
                onPressed: () async {
                  final now = DateTime.now();
                  final date = await showDatePicker(context: context, firstDate: now, lastDate: DateTime(now.year + 1), initialDate: now);
                  if (date == null) return;
                  final time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                  if (time == null) return;
                  setState(() => reminder = DateTime(date.year, date.month, date.day, time.hour, time.minute));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Hatırlatma kaydedildi (uygulama içi).')));
                },
                child: const Text('Hatırlatma Ekle'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _openTemplate(BuildContext context, InsightItem i) {
    final text = '''Hekim: ${i.owner}
Merkez: ${i.center}

Mesaj Taslağı:
Hocam merhaba, geçen görüşmemizde konuştuğumuz noktalar için kısa bir özet bırakıyorum. RCC pratiğinde sunitinib kullanımı ve 37.5 mg tek formun doz düşürme kolaylığı açısından fark yarattığını biliyorum. Uygun hastada yan etki yönetimini aşağıdaki akışla sadeleştirebiliriz.

– El-ayak sendromu: dereceye göre aralıklı kesinti/azaltma
– HTN: düzenli ölçüm + uygun antihipertansif
– Hepatotoksisite: LFT izlem, gerekirse geçici kesinti

Görüş ve eklemek istediğiniz noktaları duymak isterim.''';
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(child: Text(text)),
        ),
      ),
    );
  }
}

class InsightItem {
  final String center;
  final String owner;
  final String keyPoint;
  InsightItem({required this.center, required this.owner, required this.keyPoint});
}
