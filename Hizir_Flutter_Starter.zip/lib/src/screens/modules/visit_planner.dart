import 'package:flutter/material.dart';

class VisitPlannerScreen extends StatefulWidget {
  const VisitPlannerScreen({super.key});

  @override
  State<VisitPlannerScreen> createState() => _VisitPlannerScreenState();
}

class _VisitPlannerScreenState extends State<VisitPlannerScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController doctorCtrl = TextEditingController();
  DateTime? date;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ziyaret Planlayıcı')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: doctorCtrl,
                    decoration: const InputDecoration(labelText: 'Hekim/kurum'),
                    validator: (v) => (v == null || v.isEmpty) ? 'Zorunlu' : null,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Text(date == null ? 'Tarih seçilmedi' : date!.toIso8601String().split('T').first),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          final now = DateTime.now();
                          final picked = await showDatePicker(
                            context: context,
                            firstDate: now,
                            lastDate: DateTime(now.year + 1),
                            initialDate: now,
                          );
                          if (picked != null) setState(() => date = picked);
                        },
                        child: const Text('Tarih Seç'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate() && date != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Ziyaret kaydedildi')),
                        );
                      }
                    },
                    child: const Text('Kaydet'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
