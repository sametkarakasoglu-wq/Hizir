# Hızır (Flutter) – Telefonla 10-15 Dakikada APK

## En Kolay Yol (Appcircle – ZIP Yükleme)
1) Telefon tarayıcınla https://appcircle.io adresine gir, ücretsiz hesap aç.
2) Dashboard > **Build** > **Upload Source Code** (ZIP yükleme) yolunu seç.
3) Bu `Hizir_Flutter_Starter.zip` dosyasını yükle.
4) Platform: **Android – Flutter** seç.
5) Ayarları değiştirmeden **Build** tuşuna bas.
6) 8-12 dakika içinde **Download APK** ile indir.

> Not: Bu paket Flutter kodunu ve temel yapılandırmayı içerir. Appcircle Flutter ortamını hazır getirir. Logo eksikse `assets/logo.png` yerine default logo kullanılır.

## Logo Ekleme
- `assets/logo.png` dosyasını güncellersen açılış ekranında kendi logon görünecek.

## Özellikler
- Rx Asistan, Ziyaret Planlayıcı, KPI Paneli, İlaç Kartları
- Sürpriz Modül: **Akıllı Klinik İçgörü** (4 kritik merkez için hızlı şablonlar + hatırlatma)
